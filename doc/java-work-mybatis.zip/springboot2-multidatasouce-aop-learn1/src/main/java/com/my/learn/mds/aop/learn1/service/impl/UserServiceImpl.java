package com.my.learn.mds.aop.learn1.service.impl;

import com.my.learn.mds.aop.learn1.annotation.DataSourceAnnotation;
import com.my.learn.mds.aop.learn1.bean.TUser;
import com.my.learn.mds.aop.learn1.enums.DataSourceEnum;
import com.my.learn.mds.aop.learn1.mapper.UserMapper;
import com.my.learn.mds.aop.learn1.service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class UserServiceImpl implements IUserService {

	@Autowired
	private UserMapper userMapper;
	
	@Override
	@DataSourceAnnotation(DataSourceEnum.DATA_SOURCE_MASTER) // 指定主库
	public int insert(TUser TUser) {
		return userMapper.insert(TUser);
	}

	@Override
	//@DataSourceAnnotation(DataSourceEnum.DATA_SOURCE_SLAVE) // 指定从库
	public TUser select(Integer id) {
		return userMapper.selectByPrimaryKey(id);
	}

	@Override
	@Transactional
	@DataSourceAnnotation // 不指定，默认主库
	public int updateByPrimaryKey(TUser TUser) {
		int result = userMapper.updateByPrimaryKey(TUser);
		// result = result / 0; // 模拟异常，事务正常回滚
		return result;
	}

	@Override // 无注解，默认主库
	public int delete(Integer id) {
		return userMapper.delete(id);
	}


	@DataSourceAnnotation(DataSourceEnum.DATA_SOURCE_SLAVE) // 指定从库
	@Override
	public int insertSlave(TUser TUser) {
		return userMapper.insert(TUser);
	}

    @DataSourceAnnotation(DataSourceEnum.DATA_SOURCE_SLAVE) // 指定从库
    @Override
    public TUser selectSlave(Integer id) {
        return userMapper.selectByPrimaryKey(id);
    }
}
