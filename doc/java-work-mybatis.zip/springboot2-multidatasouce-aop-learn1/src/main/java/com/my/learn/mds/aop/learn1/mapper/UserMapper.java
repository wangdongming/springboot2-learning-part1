package com.my.learn.mds.aop.learn1.mapper;


import com.my.learn.mds.aop.learn1.bean.TUser;

public interface UserMapper {

    int insert(TUser record);

    TUser selectByPrimaryKey(Integer id);
    
    int updateByPrimaryKey(TUser record);
    
    int delete(Integer id);

}