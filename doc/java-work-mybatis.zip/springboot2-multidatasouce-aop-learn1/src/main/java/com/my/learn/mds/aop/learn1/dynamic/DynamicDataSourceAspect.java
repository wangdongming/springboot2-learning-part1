package com.my.learn.mds.aop.learn1.dynamic;

import java.lang.reflect.Method;

import com.my.learn.mds.aop.learn1.annotation.DataSourceAnnotation;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * 数据源注解切面实现
 */
@Aspect
@Order(-1)//参考另一篇add
@Component
public class DynamicDataSourceAspect {

    //参考另一篇--add
    //https://blog.csdn.net/twomr/article/details/79137056
	/*@Pointcut("execution(* com.apedad.example.service.*.list*(..))")
	public void pointCut() {
	}*/


	@Before("@annotation(dataSourceAnnotation)")
	public void before(JoinPoint point, DataSourceAnnotation dataSourceAnnotation) {
		Class<?> clazz = point.getTarget().getClass();
		MethodSignature signature = (MethodSignature) point.getSignature();
		try {
			Method method = clazz.getMethod(signature.getName(), signature.getParameterTypes());
			if (method.isAnnotationPresent(DataSourceAnnotation.class)) {
				// 根据注解设置数据源
				DataSourceAnnotation annotation = method.getAnnotation(DataSourceAnnotation.class);
				DynamicDataSourceContextHolder.setDataSource(annotation.value());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@After("@annotation(dataSourceAnnotation)")
	public void after(JoinPoint point, DataSourceAnnotation dataSourceAnnotation) {
		DynamicDataSourceContextHolder.setDefaultDataSource();
	}

}
