package com.my.learn.mds.aop.learn1;

import com.my.learn.mds.aop.learn1.bean.TUser;
import com.my.learn.mds.aop.learn1.service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;

import javax.annotation.PostConstruct;

// 去掉Spring的数据源自动配置
@SpringBootApplication(exclude = {DataSourceAutoConfiguration.class})
public class DynamicDateSourceApplication {

    public static void main(String[] args) {
        SpringApplication.run(DynamicDateSourceApplication.class, args);
    }

    @Autowired
    private IUserService iUserService;

    @PostConstruct
    public void initTest() {
        // init data
        TUser insert = new TUser();
        insert.setName("insert");
        insert.setAge(20);
        // insert
        iUserService.insert(insert);
        Integer id = insert.getId();
        System.out.println(id);

        // select
        TUser select = iUserService.select(id);
        System.out.println(select.toString());

        // update
        select.setName("update");
        int update = iUserService.updateByPrimaryKey(select);
        System.out.println(update);
        select = iUserService.select(id);
        System.out.println(select.toString());

        // delete
        int delete = iUserService.delete(id);
        System.out.println(delete);

        //-------从库

        operateSlave();


    }

    private void operateSlave(){
        TUser insert = new TUser();
        insert.setName("insert");
        insert.setAge(20);
        // insert
        iUserService.insertSlave(insert);
        Integer id = insert.getId();
        System.out.println("insertSlave-->id="+id);

        // select
        TUser select = iUserService.selectSlave(id);
        System.out.println("selectSlave-->data="+select.toString());
    }

}
