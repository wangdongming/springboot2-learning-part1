package com.my.learn.mds.aop.learn1.annotation;

import com.my.learn.mds.aop.learn1.enums.DataSourceEnum;

import java.lang.annotation.*;

/**
 * 自定义数据源注解
 */
@Documented
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface DataSourceAnnotation {
	
	DataSourceEnum value() default DataSourceEnum.DATA_SOURCE_MASTER;
	
}
