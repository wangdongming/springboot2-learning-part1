package com.my.learn.mds.aop.learn1.bean;

import lombok.Data;
import lombok.ToString;

/**
 * 测试类
 */
@Data
@ToString
public class TUser {

    private Integer id;

    private String name;

    private Integer age;
}