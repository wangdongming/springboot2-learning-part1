package com.my.learn.mds.aop.learn1.service;


import com.my.learn.mds.aop.learn1.bean.TUser;

public interface IUserService {
	
	int insert(TUser TUser);
	
	TUser select(Integer id);
	
	int updateByPrimaryKey(TUser TUser);
	
	int delete(Integer id);


	int insertSlave(TUser TUser);

    TUser selectSlave(Integer id);

}
