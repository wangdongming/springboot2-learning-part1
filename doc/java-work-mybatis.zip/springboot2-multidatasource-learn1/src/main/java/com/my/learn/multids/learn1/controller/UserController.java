package com.my.learn.multids.learn1.controller;

import com.my.learn.multids.learn1.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    UserService userService;

    @RequestMapping("/add")
    public String createUser1(Integer id, String name, Integer age) {
        userService.createUser1(id, name, age);
        return "ok";
    }

    @RequestMapping("/add2")
    public String createUser2(Integer id, String name, Integer age) {
        userService.createUser2(id, name, age);
        return "ok";
    }

}
