package com.my.learn.multids.learn1.dao.master;


import org.apache.ibatis.annotations.Param;

public interface UserDao {
    void insert(@Param("id") Integer id, @Param("name") String name, @Param("age") Integer age);
}