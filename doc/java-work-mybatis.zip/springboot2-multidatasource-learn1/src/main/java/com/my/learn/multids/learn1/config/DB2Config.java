package com.my.learn.multids.learn1.config;


import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Data
@Component
@PropertySource(value = {"dataSource.properties"})
@ConfigurationProperties(prefix = "spring.datasource.slave")
public class DB2Config {
    private String url;
    private String username;
    private String password;
    private String driverClassName;
    //setter/getter...

}
