package com.my.learn.multids.learn1.service;

import com.my.learn.multids.learn1.dao.master.UserDao;
import com.my.learn.multids.learn1.dao.slave.UserDao2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class UserService {

    @Autowired
    private UserDao dao1;

    @Autowired
    private UserDao2 dao2;

    public void createUser1(Integer id, String name, Integer age) {
        dao1.insert(id, name, age);
    }

    public void createUser2(Integer id, String name, Integer age) {
        dao2.insert(id, name, age);
    }
}
