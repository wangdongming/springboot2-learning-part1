package com.my.learn.multids.learn1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springboot2MultidatasourceLearn1Application {

    public static void main(String[] args) {
        SpringApplication.run(Springboot2MultidatasourceLearn1Application.class, args);
    }

}
