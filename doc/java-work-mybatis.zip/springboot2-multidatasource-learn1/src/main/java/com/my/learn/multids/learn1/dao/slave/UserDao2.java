package com.my.learn.multids.learn1.dao.slave;


import org.apache.ibatis.annotations.Param;

public interface UserDao2 {
    void insert(@Param("id") Integer id, @Param("name") String name, @Param("age") Integer age);
}
