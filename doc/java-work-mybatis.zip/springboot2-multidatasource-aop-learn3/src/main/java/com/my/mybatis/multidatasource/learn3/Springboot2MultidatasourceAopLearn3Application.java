package com.my.mybatis.multidatasource.learn3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springboot2MultidatasourceAopLearn3Application {

    public static void main(String[] args) {
        SpringApplication.run(Springboot2MultidatasourceAopLearn3Application.class, args);
    }

}
