package com.my.mybatis.multidatasource.learn3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springboot2MultidatasourceAopLearn3ApplicationTests {

    @Test
    void contextLoads() {
    }

}
