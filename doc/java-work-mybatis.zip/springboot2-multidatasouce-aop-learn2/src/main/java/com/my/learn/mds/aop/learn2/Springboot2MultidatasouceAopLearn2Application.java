package com.my.learn.mds.aop.learn2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;

// 去掉Spring的数据源自动配置
@SpringBootApplication(exclude = {DataSourceAutoConfiguration.class})
//@SpringBootApplication
public class Springboot2MultidatasouceAopLearn2Application {

    public static void main(String[] args) {
        SpringApplication.run(Springboot2MultidatasouceAopLearn2Application.class, args);
    }

}
