package com.my.learn.mds.aop.learn2.service;

import org.springframework.stereotype.Service;

@Service
public class DemoService {

    /*public int inserMysql(Order record){
        return orderMapper.insertSelective(record);
    }


    public int inserMssql(Test2 record){
        return test2Mapper.insertSelective(record);
    }*/

}
