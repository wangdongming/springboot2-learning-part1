package com.my.learn.mds.aop.learn2.dynamic;

import org.springframework.stereotype.Component;

/**
 * @author ttllihao
 * @description: 动态数据源上下文.
 */
@Component
public class DataSourceContextHolder {
    /**
     * 线程独立
     */
    private static ThreadLocal<String> contextHolder = new ThreadLocal<String>();

    public static final String DB_DEFAULT__MySQL = "mysql";
    public static final String DB_TYPE_SQLServer = "sqlserver";

    public static String getDataBaseType() {
        return contextHolder.get();
    }

    public static void setDataBaseType(String dataBase) {
        contextHolder.set(dataBase);
    }

    public static void clearDataBaseType() {
        contextHolder.remove();
    }
}