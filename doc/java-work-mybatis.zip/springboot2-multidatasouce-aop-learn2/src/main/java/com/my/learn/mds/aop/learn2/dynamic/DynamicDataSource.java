package com.my.learn.mds.aop.learn2.dynamic;

//import org.apache.logging.log4j.LogManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;

/**
 * @author ttllihao
 * @description: 获取数据源名
 */
public class DynamicDataSource extends AbstractRoutingDataSource {
    private Logger logger = LoggerFactory.getLogger("TestController");


    @Override
    protected Object determineCurrentLookupKey() {
        logger.info("当前数据源：{}" + DataSourceContextHolder.getDataBaseType());
        return DataSourceContextHolder.getDataBaseType();
    }
}