package com.my.learn.mds.aop.learn2.dynamic;

import com.my.learn.mds.aop.learn2.annotation.DataSourceAnno;
//import org.apache.logging.log4j.LogManager;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;

/**
 * @author ttllihao
 * @description: 动态切换数据源类
 */
@Aspect
@Component
@Order(-10)
public class DynamicDataSourceAspect {

    private Logger logger = LoggerFactory.getLogger("DynamicDataSourceAspect");


    @Before("@annotation(DataSourceAnno)")
    public void beforeSwitchDS(JoinPoint point) {
        //获得当前访问的class
        Class<?> className = point.getTarget().getClass();
        //获得访问的方法名
        String methodName = point.getSignature().getName();
        //得到方法的参数的类型
        Class[] argClass = ((MethodSignature) point.getSignature()).getParameterTypes();
        String dataSource = DataSourceContextHolder.DB_DEFAULT__MySQL;
        try {
            // 得到访问的方法对象
            Method method = className.getMethod(methodName, argClass);
            // 判断是否存在@DS注解
            if (method.isAnnotationPresent(DataSourceAnno.class)) {
                DataSourceAnno annotation = method.getAnnotation(DataSourceAnno.class);
                // 取出注解中的数据源名
                dataSource = annotation.value();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        // 切换数据源
        DataSourceContextHolder.setDataBaseType(dataSource);
    }

    @After("@annotation(DataSourceAnno)")
    public void afterSwitchDS(JoinPoint point) {
        DataSourceContextHolder.clearDataBaseType();
    }


}
