package com.my.learn.mds.aop.learn2.annotation;

import java.lang.annotation.*;
/**
 * @author ttllihao
 * @description: AOP切换数据源注解，默认值mysql，即MySQL是默认主数据源
 */
@Target({ElementType.TYPE, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface DataSourceAnno {
    String value() default "mysql";
}
