package com.my.springboo2.valid.learn3;

/**
 * 登录校验规则
 */
public interface UserLoginValidView {
}
