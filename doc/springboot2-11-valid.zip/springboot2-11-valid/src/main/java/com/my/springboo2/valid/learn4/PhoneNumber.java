package com.my.springboo2.valid.learn4;

import javax.validation.Constraint;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import javax.validation.Payload;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

//https://blog.csdn.net/nmgrd/article/details/57088192
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = PhoneNumber.Validator.class)
@SuppressWarnings("javadoc")
public @interface PhoneNumber {

    String message() default "invalid phone number";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

    public class Validator implements ConstraintValidator<PhoneNumber, String> {

        @Override
        public void initialize(PhoneNumber arg0) {

        }

        @Override
        public boolean isValid(String arg0, ConstraintValidatorContext arg1) {
            return StringUtil.isPhoneNumber(arg0);
        }
    }
}

