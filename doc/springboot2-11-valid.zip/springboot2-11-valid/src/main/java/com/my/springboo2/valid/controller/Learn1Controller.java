package com.my.springboo2.valid.controller;

import com.my.springboo2.valid.learn1.Entity2;
import com.my.springboo2.valid.learn1.Entity3;
import com.my.springboo2.valid.learn1.UserVO;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.math.BigDecimal;


//@Validated、BindingResult配合校验-----基本校验

@Controller
@RequestMapping("/")
public class Learn1Controller {

    @RequestMapping("/test")
    @ResponseBody
    public String test(){
        return "test";
    }



    //ok
    @RequestMapping("/demo1")
    @ResponseBody
    public String demo1(@Validated UserVO userVo, BindingResult result){
        String res="ok";
        if(result.hasErrors()){
            StringBuilder sb=new StringBuilder();
            for(FieldError fieldError:result.getFieldErrors()){
                sb.append(String.format("\r\n field=%s,objectName=%s,message=%s \r\n",fieldError.getField(),
                        fieldError.getObjectName(),fieldError.getDefaultMessage()));
            }
            res=sb.toString();
            System.out.println(res);
        }
        return res;
    }


    @RequestMapping("/demo2")
    @ResponseBody
    public String demo2(@Validated Entity2 entity2, BindingResult result){
        String res="ok";
        if(result.hasErrors()){
            StringBuilder sb=new StringBuilder();
            for(FieldError fieldError:result.getFieldErrors()){
                sb.append(String.format("\r\n field=%s,objectName=%s,message=%s \r\n",fieldError.getField(),
                        fieldError.getObjectName(),fieldError.getDefaultMessage()));
            }
            res=sb.toString();
            System.out.println(res);
        }
        return res;
    }


    //errors.rejectValue---返回到试图用
    @RequestMapping("/demo3")
    public String update(@ModelAttribute("b008003Bean") @Validated Entity3 b008003Bean, BindingResult errors, HttpServletRequest request, Model model){
        String strprice_setting = b008003Bean.getPrice_setting();
        String strUpperPrice = b008003Bean.getUpperPrice();
        BigDecimal price_setting = new BigDecimal(strprice_setting);
        // 分情况显示校验信息
        if(price_setting.compareTo(new BigDecimal("0.01")) == -1){
            errors.rejectValue("price_setting","","奖励额度不可小于0.01。");
        }
        if(!strprice_setting.equals("") && !strUpperPrice.equals("")){
            BigDecimal upperprice = new BigDecimal(strUpperPrice);
            if(price_setting.compareTo(upperprice) == 1){
                errors.rejectValue("price_setting","","奖励额度不允许超出限额。");
            }
        }
        if(errors.hasErrors()){
            // 数据重新复制回页面中
           /* List<B008002TypeBean> categoryList = b008002Service.getCategorys();
            b008003Bean.setCategoryList(categoryList);
            model.addAttribute("b008003Bean", b008003Bean);
            return "/b008/b008003";*/
        }
        return "";
    }



}
