package com.my.springboo2.valid.learn4;

import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

//import org.hibernate.validator.constraints.NotEmpty;

@Data
public class PayRequestDto {

    @NotEmpty(message = "支付完成时间不能空")
    @Size(min=4,max = 14, message = "支付完成时间长度最小为{min}位,不能超过{max}位")
    private String payTime;

}
