package com.my.springboo2.valid.learn6;
//http://www.belonk.com/c/spring_boot_web_bean_validation.html
//私有validator
/*
@Component
public class EmployeeFormValidator implements Validator {
    @Override
    public boolean supports(Class<?> clazz) {
        return Employee.class.equals(clazz);
    }

    @Override
    public void validate(@Nullable Object target, Errors errors) {
        // id不能为空
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "id", "id.required");
        Employee emp = (Employee) target;
        if (emp.getId() <= 0) {
            errors.rejectValue("id", "negativeValue", new Object[]{"'id'"}, "id can't be negative");
        }
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "name.required", "name cant't be null");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "role", "role.required", "role cant't be null");
    }
}*/
