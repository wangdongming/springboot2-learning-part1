package com.my.springboo2.valid.handler;

import org.springframework.validation.BindException;

import java.util.Map;

//https://www.jianshu.com/p/1ed48f2ef31a
//4、精简出参，加入全局异常处理---只处理BindException，即参数校验异常
public class ExceptionHandler {

    /*@ExceptionHandler(value = { BindException.class })
    public Map<String, Object> validationException(BindException ex) {
        log.error(ex.getBindingResult().getFieldError().getDefaultMessage());
        return ApiResultMap.errorResult(ex.getBindingResult().getFieldError().getDefaultMessage());
    }*/
}
