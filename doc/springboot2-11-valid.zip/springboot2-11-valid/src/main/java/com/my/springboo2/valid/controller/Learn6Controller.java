package com.my.springboo2.valid.controller;

import com.my.springboo2.valid.learn6.Person;
import org.hibernate.validator.constraints.Range;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.Map;

@Controller
@RequestMapping("/learn6")
public class Learn6Controller {

    //http://www.belonk.com/c/spring_boot_web_bean_validation.html
   /* @PostMapping(produces = "application/json;charset=utf-8")
    public ResultMsg add(@RequestBody @Valid Person person, Model model) {
        return ResultMsg.success(person);
    }*/



   /* @GetMapping("/validdemo")
    public Map<String,Object> demo(@Valid ValidDemo validDemo){
        return ApiResultMap.successResult(validDemo);
    }*/


   /* @Validated
    @GetMapping("/validdemo3")
    public Map<String,Object> demo3(@NotNull String str, @NotNull @Range(min = 0, max = 10) Integer a){
        return ApiResultMap.successResult(str + a);
    }*/
}
