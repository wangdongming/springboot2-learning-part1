package com.my.springboo2.valid.learn3;

/**
 * 注册校验规则
 */
public interface UserRegisterValidView {
}
