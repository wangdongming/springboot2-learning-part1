package com.my.springboo2.valid.controller;

//---自定义注解校验

import com.my.springboo2.valid.learn4.Gender;
import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import java.util.ArrayList;
import java.util.List;


//-----自定义注解校验


@Controller
@RequestMapping("/learn4")
@Validated //必须加此注解,test2方法参数验证才起作用
public class Learn4Controller {


    @GetMapping(value = "/test2")
    @ResponseBody
    public List<String> test2(
            @NotBlank(message = "用户名不能为空") String name,
            @Gender(message = "性别不合法") String gender) {
        List<String> list = new ArrayList<>();
        list.add(name);
        list.add(gender);
        return list;
    }
}
