package com.my.springboo2.valid.learn6;

import com.my.springboo2.valid.learn4.Gender;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.*;
import java.util.Date;

@Data
public class Person {
    @Size(min = 2, max = 30)
    private String name;

    @NotEmpty(message = "邮箱地址不能为空")
    @Email(message = "邮箱地址格式错误")
    private String email;

    @Min(value = 18, message = "年龄必须大于18")
    @Max(value = 100, message = "年龄必须小于100")
    private Integer age;

    private Gender gender;

    @DateTimeFormat(pattern = "MM/dd/yyyy")
    @Past(message = "生日必须为过去的时间")
    private Date birthday;

    //这里的@Phone为自定义注解，有兴趣可以查阅源码
    //@Phone(message = "号码格式不正确")
    private String phone;
}
