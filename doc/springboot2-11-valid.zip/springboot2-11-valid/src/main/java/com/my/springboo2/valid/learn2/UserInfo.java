package com.my.springboo2.valid.learn2;

import lombok.Data;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

@Data
public class UserInfo {

    @NotBlank
    private String name;

    @Min(value = 1,message = "最小年龄为1岁")
    @Max(value = 120,message = "最大年龄为120岁")
    private int age;


}
