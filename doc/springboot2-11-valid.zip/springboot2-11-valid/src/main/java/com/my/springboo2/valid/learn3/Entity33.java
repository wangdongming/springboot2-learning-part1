package com.my.springboo2.valid.learn3;

import lombok.Data;
import org.hibernate.validator.constraints.Length;

import javax.validation.GroupSequence;
import javax.validation.constraints.Pattern;
import java.io.Serializable;

//https://blog.csdn.net/smallnetter/article/details/94954728
/**
 * 通过@GroupSequence指定验证顺序：先验证First分组，如果有错误立即返回而不会验证Second分组，接着如果First分组验证通过了，
 * 那么才去验证Second分组，最后指定User.class表示那些没有分组的在最后。这样我们就可以实现按顺序验证分组了。
 */
@Data
@GroupSequence({First.class, Second.class, Entity33.class})
public class Entity33 implements Serializable {
    private Long id;

    @Length(min = 5, max = 20, message = "{user.name.length.illegal}", groups = {First.class})
    @Pattern(regexp = "[a-zA-Z]{5,20}", message = "{user.name.illegal}", groups = {Second.class})
    private String name;

    private String password;

    //级联验证：
    //@Valid
    //@ConvertGroup(from=First.class, to=Second.class)
    //private Organization o;
    //级联验证只要在相应的字段上加@Valid即可，会进行级联验证；@ConvertGroup的作用是当验证o的分组是First时，
    // 那么验证o的分组是Second，即分组验证的转换。
}
