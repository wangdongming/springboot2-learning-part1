package com.my.springboo2.valid.controller;

import com.alibaba.fastjson.JSON;
import com.my.springboo2.valid.learn2.User;
import com.my.springboo2.valid.learn8.Spitter;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@Controller
@RequestMapping("/learn8")
public class Learn8Controller {

    //https://blog.csdn.net/u012811841/article/details/82428989
    //https://blog.csdn.net/u012811841/article/details/82428989
    /*@RequestMapping(value = "validate", method = RequestMethod.POST)
    @ResponseBody
    public GroupInfo validate(@Validated @RequestBody GroupInfo group, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            for (ObjectError object : bindingResult.getAllErrors()) {

                System.out.println(object.getDefaultMessage());
            }
        }
        return group;
    }*/




    //测试国际化验证信息
    @PostMapping(value="/test1")
    @ResponseBody
    public String test1(@RequestBody @Valid Spitter spitter) {
        return JSON.toJSONString(spitter);
    }



}
