package com.my.springboo2.valid.learn7;

import com.alibaba.fastjson.JSON;
//import com.rq.aop.common.R;
//import com.rq.aop.common.ResponseBuilder;
//import com.rq.aop.common.enums.ResultCode;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.FieldError;

import java.util.ArrayList;
import java.util.List;

/**
 * Controller参数校验拦截器
 *
 */
//@Component
//@Aspect
public class ValidationInterceptor {

    private final Logger log = LoggerFactory.getLogger(getClass());

    /**
     * 拦截{@link com.rq.aop.controller.HelloController}包下所有返回值类型是{@link R}
     * 且最后一个参数是{@link Errors}的公共方法
     *
     * @param pjp    连接点
     * @param errors 校验结果对象
     * @return 请求参数校验错误信息，或者请求正常执行的结果
     * @throws Throwable 方法调用抛出的异常
     */
    @Around(value = "execution(com.rq.aop.common.R com.rq.aop.controller..*(..)) && args(.., errors))")
    public R processValidation(ProceedingJoinPoint pjp, Errors errors) throws Throwable {
        if (errors.hasFieldErrors()) {
            List<ErrorMessage> errorMessages = getErrorMessages(errors);
            // 被校验的参数在Errors参数前一位
            Object[] arguments = pjp.getArgs();
            int index = arguments.length - 2;
            if (index >= 0) {
                Object validateTarget = arguments[index];
                log.info("请求参数有误: {}, 错误信息: {}", JSON.toJSONString(validateTarget), JSON.toJSONString(errorMessages));
            }
            return ResponseBuilder.error(ResultCode.PARAM_ERROR, getErrorMessages(errors));
        } else {
            return (R) pjp.proceed();
        }
    }

    private List<ErrorMessage> getErrorMessages(Errors errors) {
        List<ErrorMessage> messages = new ArrayList<>();
        for (FieldError fieldError : errors.getFieldErrors()) {
            messages.add(new ErrorMessage(
                    fieldError.getField(),
                    fieldError.getRejectedValue(),
                    fieldError.getDefaultMessage()));
        }
        return messages;
    }

    static class ErrorMessage {
        private String fieldName;
        private Object rejectedValue;
        private String message;

        ErrorMessage(String fieldName, Object rejectedValue, String message) {
            this.fieldName = fieldName;
            this.rejectedValue = rejectedValue;
            this.message = message;
        }

        public String getFieldName() {
            return fieldName;
        }

        public Object getRejectedValue() {
            return rejectedValue;
        }

        public String getMessage() {
            return message;
        }
    }
}
