package com.my.springboo2.valid.controller;

import com.alibaba.fastjson.JSON;
import com.my.springboo2.valid.learn1.Entity2;
import com.my.springboo2.valid.learn2.Animal;
import com.my.springboo2.valid.learn2.User;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.validation.Valid;
import java.util.HashMap;
import java.util.Map;

//@Valid注解---基本、级联/嵌套校验测试
@Controller
@RequestMapping("/learn2")
@Slf4j
public class Learn2Controller {


    @PostMapping(value="/test1")
    @ResponseBody
    public String test1(@RequestBody @Valid User user) {
        return JSON.toJSONString(user);
    }



     //使用@Valid+BindingResult进行controller参数校验
    //https://blog.csdn.net/FU250/article/details/80247930
    //https://blog.csdn.net/FU250/article/details/80247930

    //对password的非空校验已经生效了，直接抛出异常
   /* @PostMapping
    public Animal createAnimal(@Valid @RequestBody Animal animal){
        log.info(animal.toString());
        return animal;
    }*/

    //如果不想抛出异常，想返回校验信息给前端，
    //这个时候就需要用到BindingResult了，修改创建动物的方法，添加BindingResult参数：
   /* @PostMapping
    public Animal createAnimal(@Valid @RequestBody Animal animal, BindingResult bindingResult){
        if (bindingResult.hasErrors()){
            bindingResult.getAllErrors().forEach(o ->{
                FieldError error = (FieldError) o;
                log.info(error.getField() + ":" + error.getDefaultMessage());
            });
        }
        log.info(animal.toString());
        return animal;
    }*/


   //为了满足我们编码需要我们需要进行代码改造，1.不能直接返回animal。2.返回的提示信息得是用户可读懂的信息。
   //controller方法改造如下，通过Map对象传递请求成功后的信息或错误提示信息。
    @PostMapping
    public Map<String,Object> createAnimal(@Valid @RequestBody Animal animal, BindingResult bindingResult){
        log.info(animal.toString());
        Map<String,Object> result = new HashMap<>();
        if (bindingResult.hasErrors()){
            FieldError error = (FieldError) bindingResult.getAllErrors().get(0);
            result.put("code","400");//错误编码400
            result.put("message",error.getDefaultMessage());//错误信息
            return result;
        }
        result.put("code","200");//成功编码200
        result.put("data",animal);//成功返回数据
        return result;
    }

}
