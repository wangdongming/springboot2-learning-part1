package com.my.springboo2.valid.learn7;

import java.io.Serializable;

public class R<T> implements Serializable {

    private String sign;

    private String code;

    private String message;

    private T data;

    public static <T> Builder<T> builder() {
        return new Builder<>();
    }

    private R() {
    }

    private R(Builder<T> builder) {
        this.sign = builder.sign;
        this.code = builder.code;
        this.message = builder.message;
        this.data = builder.data;
    }

    public static class Builder<T> {
        private String sign;

        private String code;

        private String message;

        private String traceId;

        private T data;

        private Builder() {
        }

        public Builder<T> sign(String sign) {
            this.sign = sign;
            return this;
        }

        public Builder<T> code(String code) {
            this.code = code;
            return this;
        }

        public Builder<T> message(String message) {
            this.message = message;
            return this;
        }

        public Builder<T> traceId(String traceId) {
            this.traceId = traceId;
            return this;
        }

        public Builder<T> data(T data) {
            this.data = data;
            return this;
        }

        public R<T> build() {
            return new R<>(this);
        }
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }


    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "R{" + "sign='" + sign + '\'' +
                ", code='" + code + '\'' +
                ", message='" + message + '\'' +
                ", data=" + data +
                '}';
    }
}

