package com.my.springboo2.valid.learn5;


import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.NotBlank;
import java.util.List;

/**
 * @Auther: Summer
 * @Date: 2019-01-05 11:35
 * @Description: 测试实体类
 * @versions:1.0
 */
@Getter
@Setter
public class TestVo {

    @NotBlank   // @NotBlank 必须是String类型的
    private String msg;

    @NotNull  // @NotNull:不能为null，但可以为empty,没有Size的约束
    private String id;

    private List<String> str;
}
