package com.my.springboo2.valid.learn1;

import lombok.Data;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.Date;

//https://www.bbsmax.com/A/A2dmVQjOze/
@Data
public class UserVO {

    @NotNull(message = "uuid 不能为空!")
    private String uuid;

    @NotNull(message = "name不能为null!")
    @NotEmpty(message = "用户名称不能为空!")
    private String name;

    private String passwd;

    private String sex;

    private Date birthday;

    @Length(min = 11, max = 11, message = "电话号码长度必须为11位！")
    private String phone;

    private String photo;

    @Email(message = "电子邮箱地址不合法！")
    private String email;

    private String yxbz;

    private String sorts;

    //.....setter/getter
}