package com.my.springboo2.valid.controller;

//import com.mmall.common.JsonDate;
//import com.mmall.param.TestVo;
//import com.mmall.util.BeanValidator;
import com.my.springboo2.valid.learn5.BeanValidator;
import com.my.springboo2.valid.learn5.TestVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import java.util.Map;

//----通过validator工具类校验

@Controller
@RequestMapping("/learn5")
@Slf4j
public class Learn5Controller {


    @RequestMapping("/validate")
    @ResponseBody
    public String validate(TestVo vo){
        log.info("validate");
        try {
            Map<String,String> map = BeanValidator.validateObject(vo);
            if(map != null && map.entrySet().size() >0){
                for (Map.Entry<String,String> entry: map.entrySet()){
                    log.info("{}->{}",entry.getKey(),entry.getValue());
                }
            }
        }catch (Exception e){
            log.error("validate-->error:",e);
        }
        //return JsonDate.success("test,validate");
        return "validate success";
    }
}
