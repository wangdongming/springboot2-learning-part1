package com.my.springboo2.valid.entity;

import com.my.springboo2.valid.annotation.Price;
import lombok.Data;

import javax.validation.constraints.NotEmpty;

@Data
public class Product {
    // 必须非空
    @NotEmpty
    private String name;
    // 必须在 8000 至 10000 的范围内
    // @Price 是一个定制化的 constraint
    @Price
    private float price;
}

