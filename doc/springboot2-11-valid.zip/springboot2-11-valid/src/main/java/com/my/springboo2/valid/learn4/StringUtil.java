package com.my.springboo2.valid.learn4;

import org.springframework.util.StringUtils;

import java.util.regex.Pattern;

public class StringUtil {

    public final static String PATTERN_PHONE = "^((13[0-9])|(14[5,7])|(15[^4,\\D])|(17[0,5-8])|(18[0-9]))\\d{8}$";

    public static boolean isPhoneNumber(String phone) {
        if (StringUtils.isEmpty(phone)) {
            return false;
        }
        boolean isMatch = Pattern.matches(PATTERN_PHONE, phone);
        //return match(RegExp.PHONE, phone);
        return isMatch;
    }
}
