package com.my.springboo2.valid.learn2;

import lombok.Data;
import lombok.Data;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.Range;

import javax.validation.Valid;
import javax.validation.constraints.*;
import java.math.BigDecimal;
import java.util.List;

//嵌套类型校验
@Data
public class User {

    //正则校验
    @NotBlank(message = "用户名不能为空")
    @Length(min=5, max=20, message="用户名长度必须在5-20之间")
    @Pattern(regexp = "^[a-zA-Z_]\\w{4,19}$", message = "用户名必须以字母下划线开头，可由字母数字下划线组成")
    private String userName;

    //验证必须为int且范围在 A-B之间
    @Range(min=0, max=4)
    private int scale;//基础规格

    //验证List不为空
    @NotEmpty
    private List<String> lansList;

    //对象内包含List<对象>的校验
    @NotEmpty
    @Valid
    private List<UserInfo> userList;
}
