package com.my.springboo2.valid.learn7;

//import com.rq.aop.common.enums.ResultCode;

public class ResponseBuilder {

    private ResponseBuilder() {}

    public static <T> R<T> success() {
        return of(ResultCode.SUCCESS, null);
    }

    public static <T> R<T> success(T data) {
        return of(ResultCode.SUCCESS, data);
    }

    public static <T> R<T> exception() {
        return of(ResultCode.EXCEPTION, null);
    }

    public static <T> R<T> error(ResultCode exception, T data) {
        return of(exception, data);
    }

    private static <T> R<T> of(ResultCode result, T data) {
        return R
                .<T>builder()
                .code(result.getCode())
                .message(result.getDesc())
                .data(data)
                .build();
    }
}
