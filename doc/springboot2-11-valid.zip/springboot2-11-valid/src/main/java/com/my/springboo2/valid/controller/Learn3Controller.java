package com.my.springboo2.valid.controller;

import com.alibaba.fastjson.JSON;
import com.my.springboo2.valid.learn3.*;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.Date;

//-----------------分组校验

@Controller
@RequestMapping("/learn3")
public class Learn3Controller {

    @PostMapping(value = "/register")
    @ResponseBody//表明对User对象的校验，启用UserRegisterValidView规则
    public String register(@Validated(value = {UserRegisterValidView.class}) @RequestBody UserBmo user) {
        return JSON.toJSONString(user);
    }


    //Sat Nov 02 21:25:32 CST 2019
   /* public static void main(String[] args) {
        System.out.println(new Date());
    }*/



    //---------------https://blog.csdn.net/smallnetter/article/details/94954728
    //通过@Validate注解标识要验证的分组
    @RequestMapping("/save")
    public String save(@Validated({Second.class}) Entity3 user, BindingResult result) {
        if(result.hasErrors()) {
            return "error";
        }
        return "success";
    }

    //如果要验证两个的话，可以这样@Validated({First.class, Second.class})。
    @RequestMapping("/save2")
    public String save2(@Validated({First.class, Second.class}) Entity3 user, BindingResult result) {
        if(result.hasErrors()) {
            return "error";
        }
        return "success";
    }

    //通过分组来指定顺序
    //@GroupSequence指定分组验证顺序：


    //级联验证
    //@ConvertGroup(from=First.class, to=Second.class)


}
