package com.my.springboo2.valid.learn3;

import com.my.springboo2.valid.learn4.IsQQEmail;
import lombok.Data;

import javax.validation.constraints.*;
import java.math.BigDecimal;
import java.util.Date;


//https://blog.csdn.net/qq_33144861/article/details/77895366
@Data
public class UserBmo {

    @NotBlank(message = "用户名不能为空")
    private String userName;

    @NotBlank(message = "密码不能为空")
    private String password;

    // 若填写了groups，则该参数验证只在对应验证规则下启用
    @Past(groups = { UserRegisterValidView.class }, message = "出生日期不符合要求")
    private Date birthday;

    @DecimalMin(value = "0.1", message = "金额最低为0.1")
    @NotNull(message = "金额不能为空")
    private BigDecimal balance;

    @AssertTrue(groups = { UserRegisterValidView.class, UserLoginValidView.class }, message = "标记必须为true")
    private boolean flag;

    @Min(value = 18, message = "年龄不能小于18")
    private Integer age;


    @IsQQEmail(message = "邮箱错误")
    private String email;

}


