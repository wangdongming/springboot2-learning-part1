package com.my.springboo2.valid.learn7;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@AllArgsConstructor
@Getter
public enum ResultCode {
    SUCCESS("1","成功"),
    EXCEPTION("-1","异常"),
    PARAM_ERROR("-2","参数错误");

    private String code;
    private String desc;
}
