package com.my.springboo2.valid.learn2;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.util.Date;

@Data
public class Animal {

    private String name;

    private Integer age;


    @NotBlank
    private String password;


    private Date birthDay;
}


