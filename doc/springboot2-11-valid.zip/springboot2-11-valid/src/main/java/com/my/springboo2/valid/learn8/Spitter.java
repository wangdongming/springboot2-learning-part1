package com.my.springboo2.valid.learn8;

import lombok.Data;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

//错误信息国际化
//https://blog.csdn.net/championhengyi/article/details/78497387
@Data
public class Spitter {
    @NotNull
    @Size(min = 5, max = 16, message = "{username.size}")
    private String username;

    @NotNull
    @Size(min = 5, max = 25, message = "{password.size}")
    private String password;

    @NotNull
    @Size(min = 2, max = 30, message = "{firstName.size}")
    private String firstName;

    @NotNull
    @Size(min = 2, max = 30, message = "{lastName.size}")
    private String lastName;
}
