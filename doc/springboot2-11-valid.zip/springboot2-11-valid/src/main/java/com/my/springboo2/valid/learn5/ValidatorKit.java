package com.my.springboo2.valid.learn5;

import org.springframework.util.CollectionUtils;

import javax.validation.ConstraintViolation;

import javax.validation.Validation;

import javax.validation.Validator;

import javax.validation.groups.Default;

import java.util.HashMap;

import java.util.Map;

import java.util.Set;

import java.util.regex.Matcher;

import java.util.regex.Pattern;

/**
 * 验证工具
 */
//基于Hibernate Validator参数校验
//https://www.jianshu.com/p/e70cb8ba8f48
public class ValidatorKit {

    private static Validator validator = Validation.buildDefaultValidatorFactory().getValidator();

    //验证某个实体类
   /* public static <T> ValidationResult validateEntity(T obj) {
        ValidationResult result = new ValidationResult();
        Set<ConstraintViolation<T>> set = validator.validate(obj, Default.class);
        if (CollectionUtils.isNotEmpty(set)) {
            result.setHasErrors(true);
            Map errorMsg = new HashMap<>();
            String firstErrorMsg = null;
            for (ConstraintViolation cv : set) {
                if (firstErrorMsg == null) {
                    firstErrorMsg = cv.getMessage();
                }
                errorMsg.put(cv.getPropertyPath().toString(), cv.getMessage());
            }
            result.setFirstErrorMsg(firstErrorMsg);
            result.setErrorMsg(errorMsg);
        }
        return result;
    }

    //验证某个实体的某个属性
    public static <T> ValidationResult validateProperty(T obj, String propertyName) {
        ValidationResult result = new ValidationResult();
        Set<ConstraintViolation<T>> set = validator.validateProperty(obj, propertyName, Default.class);
        if (CollectionUtils.isNotEmpty(set)) {
            result.setHasErrors(true);
            Map errorMsg = new HashMap<>();
            String firstErrorMsg = null;
            for (ConstraintViolation cv : set) {
                if (firstErrorMsg == null) {
                    firstErrorMsg = cv.getMessage();
                }
                errorMsg.put(propertyName, cv.getMessage());
            }
            result.setFirstErrorMsg(firstErrorMsg);
            result.setErrorMsg(errorMsg);

        }
        return result;
    }*/

}
