package com.my.springboo2.valid.learn1;

import lombok.Data;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.*;
import java.math.BigDecimal;

@Data
public class Entity3 {

    /** 标题 */
    @Length(max = 30, message = "只允许输入30个字")
    @NotBlank(message = "请输入标题")
    private String name;

    /** 奖励额度 */
    @Digits(integer = 8, fraction = 2)
    @NotBlank(message = "请输入奖励额度")
    private String price_setting;

    /** 达币数量 */
    @Digits(integer = 8, fraction = 2)
    @NotNull()
    private BigDecimal money;

    @NotEmpty
    private String upperPrice;

}


