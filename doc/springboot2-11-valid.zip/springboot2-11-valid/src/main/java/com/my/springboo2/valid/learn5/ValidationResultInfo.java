package com.my.springboo2.valid.learn5;


import lombok.Data;

import java.util.Map;

/**
 * 校验结果
 */
@Data
public class ValidationResultInfo {

    //校验结果是否有错

    private boolean hasErrors;

    //第一条错误信息

    private String firstErrorMsg;

    //校验错误信息

    private Map errorMsg;

    //getter setter method...

}
