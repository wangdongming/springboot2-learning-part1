package com.my.springboo2.valid.learn3;

public interface Second {
}
