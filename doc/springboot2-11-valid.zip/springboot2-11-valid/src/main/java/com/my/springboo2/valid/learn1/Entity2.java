package com.my.springboo2.valid.learn1;

import lombok.Data;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

//https://blog.csdn.net/qq_39822451/article/details/83989415

@Data
public class Entity2 {

    /**
     * 登录名
     */
    @Length(max = 10, message = "{valid.length}")
    @NotBlank(message = "{valid.staffname}")
    @Pattern(regexp = "^[\u4E00-\u9FA5A-Za-z0-9_]+$", message = "{valid.format}")
    private String staffname;
    /**
     * 姓名
     */
    @Length(max = 10, message = "{valid.length}")
    @NotBlank(message = "{valid.staffrealname}")
    @Pattern(regexp = "^[\u4E00-\u9FA5A-Za-z0-9_]+$", message = "{valid.format}")
    private String realname;
    /**
     * 登录密码
     */
    @Length(min = 1, max = 50, message = "{valid.password.length}")
    @NotBlank(message = "{valid.password.notblank}")
    @Pattern(regexp = "^[0-9a-zA-Z_]{1,}$", message = "{valid.format}")
    private String password;
    /**
     * 确认密码
     */
    @NotBlank(message = "{valid.repassword.notblank}")
    @Pattern(regexp = "^[0-9a-zA-Z_]{1,}$", message = "{valid.format}")
    private String password2="";
    /**
     * 电话
     */
    @Pattern(regexp = "^[150[0-9]+]{11}", message = "{valid.tel}")
    private String tel;
    /**
     * 邮箱
     */
    @Email(message = "{valid.mail}")
    private String mail;


    @NotEmpty(message = "name不能为空!")
    private String name="";

}


