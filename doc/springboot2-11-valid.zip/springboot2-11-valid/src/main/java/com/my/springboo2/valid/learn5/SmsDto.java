package com.my.springboo2.valid.learn5;

import lombok.Data;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.*;

@Data
public class SmsDto {
    //public class SmsDto extends BaseDto{
    @Length(min = 2, message = "参数有误")

    @NotBlank(message = "短信参数不允许为空")

    private String params;//短信模板参数,json结构

    @Min(value = 1L, message = "模板id有误")

    @Max(value = Long.MAX_VALUE, message = "模板id有误")

    @NotNull(message = "模板id不允许为空")

    private Long templateId;//模板id

    @Length(min = 11, max = 560, message = "手机号长度必须是11~560")

    @NotNull(message = "手机号不允许为空")

    private String phones;//手机号,多个逗号隔开

    @NotBlank(message = "创建人不能为空,如果是系统发送,请传入system")

    private String createBy;//创建人

    @NotBlank(message = "ip不能为空,如果是系统发送,请传入localhost")

    private String ip;//用户的ip地址

//getter setter method...

}

