package com.my.springboo2.valid.learn1;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import java.util.Set;

public class ValidateTest {


    public static void main(String[] args) {
        UserVO userVO=new UserVO();

        ValidateTest.validBean(userVO);

        System.out.println("------");

        userVO.setPhone("135");
        userVO.setEmail("abc");
        ValidateTest.validBean(userVO);


    }

    public static void validBean(Object targerBean) {
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        Validator validator = factory.getValidator();
        Set<ConstraintViolation<Object>> violations = validator.validate(targerBean);
        for (ConstraintViolation<Object> violation : violations) {
            System.out.println(violation.getMessage());
        }
    }
}
