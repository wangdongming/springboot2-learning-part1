package com.my.springboo2.valid.learn2;

import lombok.Data;
import javax.validation.constraints.*;
@Data
public class ParentInfo {

    @NotBlank(message="父亲名称不能为空")
    private String fatherName;

    @NotBlank(message="母亲名称不能为空")
    private String motherName;
}
