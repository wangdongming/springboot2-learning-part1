package com.my.springboo2.valid.handler;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

//https://www.jianshu.com/p/1ed48f2ef31a
//另一种方式，使用 spring 的 @Validated 注解:
//配置 MethodValidationPostProcessor
@Component
public class MyMvcConfig {

    //启动报错---默认已开启---不用再配置
   /* @Bean
    public MyMvcConfig methodValidationPostProcessor() {
        return new MyMvcConfig();
    }*/
}
