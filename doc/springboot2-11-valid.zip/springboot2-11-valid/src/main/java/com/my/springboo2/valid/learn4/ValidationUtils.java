package com.my.springboo2.valid.learn4;

import java.util.Iterator;
import java.util.Set;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.groups.Default;

import org.hibernate.validator.HibernateValidator;


//https://blog.csdn.net/zalan01408980/article/details/79059434
public class ValidationUtils {

    /**
     * 使用hibernate的注解来进行验证
     */
    private static Validator validator = Validation
            .byProvider(HibernateValidator.class).configure().failFast(true).buildValidatorFactory().getValidator();


    public static void main(String[] args) {
        PayRequestDto payRequestDto=new PayRequestDto();
        payRequestDto.setPayTime("201");
        String msg= ValidationUtils.validate(payRequestDto);
        System.out.println(msg);
    }


    //注解验证参数
    public static <T> String validate(T obj) {
       /* Set<ConstraintViolation<T>> constraintViolations = validator.validate(obj);
        // 抛出检验异常
        if (constraintViolations.size() > 0) {
            String errorMsg = String.format("参数校验失败:%s", constraintViolations.iterator().next().getMessage());
            //throw new Exception(errorMsg);
            return errorMsg;
        }*/
        Set<ConstraintViolation<T>> constraintViolations = validator.validate(obj, Default.class);
        if(constraintViolations!=null && constraintViolations.size()>0){
            StringBuilder sb=new StringBuilder();
            Iterator<ConstraintViolation<T>>  it=constraintViolations.iterator();
            while (it.hasNext()){
                ConstraintViolation<T> t=it.next();
                sb.append(t.getMessage());
            }
            return  sb.toString();
        }
        return null;
    }
}