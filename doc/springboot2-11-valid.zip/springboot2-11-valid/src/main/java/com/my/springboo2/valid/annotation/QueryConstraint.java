package com.my.springboo2.valid.annotation;

public @interface QueryConstraint {
}
