package com.my.springboo2.valid.learn2;

import com.my.springboo2.valid.learn4.Money;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

//基本校验练习
@Data
public class StudentInfo {

    @NotBlank(message="用户名不能为空")
    private String userName;

    @NotBlank(message="年龄不能为空")
    @Pattern(regexp="^[0-9]{1,2}$",message="年龄是整数")
    private String age;

    /**
     * 如果是空，则不校验，如果不为空，则校验
     */
    @Pattern(regexp="^[0-9]{4}-[0-9]{2}-[0-9]{2}$",message="出生日期格式不正确")
    private String birthday;

    @NotBlank(message="学校不能为空")
    private String school;

    //-------learn4--
    //3、自定义校验规则
    @NotNull(message="金额不能为空")
    @Money(message="金额格式不正确")
    private Double money;


    //4.级联校验
    // 如果校验的对象中包含另一个对象信息时，校验也要同时校验另一个对象，则可以使用@Valid
    /**
     * 如果不加@NotNull，则prentInfo=null时，不会对ParentInfo内的字段进行校验
     */
    @NotNull(message="父母信息不能为空")
    @Valid
    private ParentInfo parentInfo;
}
