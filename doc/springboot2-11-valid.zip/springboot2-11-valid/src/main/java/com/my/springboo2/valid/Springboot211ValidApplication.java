package com.my.springboo2.valid;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication(scanBasePackages = {"com.my.springboo2.valid"})
//@ComponentScan(basePackages = {"com.my.springboo2.valid"})
public class Springboot211ValidApplication {

    public static void main(String[] args) {
        SpringApplication.run(Springboot211ValidApplication.class, args);
    }

}
