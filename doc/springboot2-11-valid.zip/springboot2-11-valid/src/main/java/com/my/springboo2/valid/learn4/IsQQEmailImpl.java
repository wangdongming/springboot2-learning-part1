package com.my.springboo2.valid.learn4;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

//https://blog.csdn.net/qq_33144861/article/details/77895366
public class IsQQEmailImpl implements ConstraintValidator<IsQQEmail, String> {

    @Override
    public void initialize(IsQQEmail isQQEamil) {
        // TODO Auto-generated method stub
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        // TODO Auto-generated method stub

        if (value == null) {
            return false;
        }

        // 进行QQ邮箱格式的简单判断，实际开发用正则
        if (value.endsWith("@qq.com") || value.endsWith("@QQ.COM")) {
            return true;
        }

        return false;

    }

}
