package com.my.springboo2.valid;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springboot211ValidApplicationTests {

    @Test
    void contextLoads() {
    }

}
