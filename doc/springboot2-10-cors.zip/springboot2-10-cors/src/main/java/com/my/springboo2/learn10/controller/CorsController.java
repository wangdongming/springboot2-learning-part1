package com.my.springboo2.learn10.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Controller
public class CorsController {

    //3.3.使用CrossOrigin注解（局部跨域配置）---请求有错
    //将CrossOrigin注解加在Controller层的方法上，该方法定义的RequestMapping端点将支持跨域访问
    //将CrossOrigin注解加在Controller层的类定义处，整个类所有的方法对应的RequestMapping端点都将支持跨域访问
   /* @RequestMapping("/cors1")
    @ResponseBody
    //@CrossOrigin(origins = "http://localhost:8080/", maxAge = 3600)
    @CrossOrigin(origins = "*", maxAge = 3600)
    public String cors1( ){
        return "cors1";
    }*/

    //3.4 使用HttpServletResponse设置响应头(局部跨域配置)---请求有错
    //这种方式略显麻烦，不建议在SpringBoot项目中使用。
   /* @RequestMapping("/cors2")
    @ResponseBody
    public String cors2(HttpServletResponse response){
        //使用HttpServletResponse定义HTTP请求头，最原始的方法也是最通用的方法
        //response.addHeader("Access-Control-Allow-Origin", "http://localhost:8080");
        response.addHeader("Access-Control-Allow-Origin", "*");
        return "cors2";
    }*/


    @RequestMapping("/test")
    @ResponseBody
    public String test(HttpServletRequest request, HttpServletResponse response){
        System.out.println("request header="+request.getHeader("Origin"));
        return "test";
    }
}
