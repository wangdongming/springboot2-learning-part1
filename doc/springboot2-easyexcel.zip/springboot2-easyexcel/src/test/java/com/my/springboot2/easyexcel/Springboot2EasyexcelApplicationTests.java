package com.my.springboot2.easyexcel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springboot2EasyexcelApplicationTests {

    @Test
    void contextLoads() {
    }

}
