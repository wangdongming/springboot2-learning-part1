package com.my.springboot2.knife4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springboot2Knife4jNewApplication {

    public static void main(String[] args) {
        SpringApplication.run(Springboot2Knife4jNewApplication.class, args);
    }

}
