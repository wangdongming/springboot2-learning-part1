package com.my.springboo2.tpl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springboot2TplApplication {

	public static void main(String[] args) {
		SpringApplication.run(Springboot2TplApplication.class, args);
	}

}
